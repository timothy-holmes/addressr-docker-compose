# CI/CD

During the CI run, we want to

1. Do the test runs
2. Do other QA
3. If that passes, then
4. bump the version & commit
5. package the release
6. upload the release
7. create the deployable
8. run terraform to do the deploy

